## 6 dof arm manipulation hardware discription

### Joint 1: <Nema 23> <inTorque 18kg-cm> <Gear ratio 1:10> <friction loss 0.01> 

### Joint 2: <Nema 23> <inTorque 31kg-cm> <Gear ratio 1:100> <friction loss 0.01> 

### Joint 3: <Nema 23> <inTorque 18Kg-cm> <Gear ratio 1:50> <friction loss 0.01>

### Joint 4: <Nema 17> <inTorque 6.5Kg-cm> <Gear ratio 1:10> <friction loss 0.01> 

### Joint 5: <Nema 17> <inTorque 4.8Kg-cm> <Gear ratio 1:20> <friction loss 0.01> 

### Joint 6: <Nema 17> <inTorque 4.8Kg-cm> <Gear ratio 1:20> <friction loss 0.01> 